if (typeof module === 'object') {
  window.module = module;
  module = undefined;
}